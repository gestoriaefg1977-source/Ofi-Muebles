import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Features } from "@/components/features"
import { SpecialOffers } from "@/components/special-offers"
import { Products } from "@/components/products"
import { Categories } from "@/components/categories"
import { Design3D } from "@/components/design-3d"
import { About } from "@/components/about"
import { ShippingNote } from "@/components/shipping-note"
import { CTA } from "@/components/cta"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main>
      <Header />
      <Hero />
      <Features />
      <SpecialOffers />
      <Products />
      <Categories />
      <Design3D />
      <ShippingNote />
      <About />
      <CTA />
      <Contact />
      <Footer />
    </main>
  )
}
