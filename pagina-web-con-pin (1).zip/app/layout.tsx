import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: 'OFI-MUEBLES | Productividad en Cada Espacio',
  description: 'Distribuidor autorizado de muebles de oficina ergonómicos. Sillas ejecutivas, operativas, mobiliario y soluciones para tu espacio de trabajo.',
  keywords: 'muebles de oficina, sillas ergonómicas, escritorios, mobiliario corporativo, muebles ejecutivos',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className="bg-background" data-scroll-behavior="smooth" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
