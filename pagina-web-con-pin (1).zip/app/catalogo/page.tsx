"use client"

import { useState, useMemo } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ShippingNote } from "@/components/shipping-note"
import { Search, Filter, MessageCircle, ArrowLeft, Grid, List, X } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

// Catálogo completo de productos GERSA
const productos = [
  // SILLERÍA EJECUTIVA
  { id: 1, nombre: "BOLT ALTA", categoria: "silleria-ejecutiva", imagen: "/images/productos/bolt-alta.jpg", nuevo: true, destacado: true, descripcion: "Silla ejecutiva de respaldo alto con diseño moderno y ergonómico" },
  { id: 2, nombre: "BOLT BAJA", categoria: "silleria-ejecutiva", imagen: "/images/productos/bolt-baja.jpg", nuevo: true, destacado: true, descripcion: "Silla ejecutiva de respaldo medio con máximo confort" },
  { id: 3, nombre: "NICOLE ALTA", categoria: "silleria-ejecutiva", imagen: "/images/productos/nicole-alta.jpg", nuevo: true, destacado: true, descripcion: "Diseño elegante con respaldo alto y soporte lumbar" },
  { id: 4, nombre: "NICOLE BAJA", categoria: "silleria-ejecutiva", imagen: "/images/productos/nicole-baja.jpg", nuevo: true, destacado: true, descripcion: "Versión media de la línea Nicole con acabados premium" },
  { id: 5, nombre: "YUE ALTA", categoria: "silleria-ejecutiva", imagen: "/images/productos/yue-alta.jpg", nuevo: false, destacado: true, descripcion: "Silla ejecutiva con respaldo de malla transpirable" },
  { id: 6, nombre: "YUE BAJA", categoria: "silleria-ejecutiva", imagen: "/images/productos/yue-baja.jpg", nuevo: false, destacado: true, descripcion: "Diseño ergonómico con ajuste de altura y inclinación" },
  { id: 7, nombre: "FENT NEGRO ALTA", categoria: "silleria-ejecutiva", imagen: "/images/productos/fent-alta.jpg", nuevo: false, destacado: true, descripcion: "Silla ejecutiva en negro con acabados modernos" },
  { id: 8, nombre: "FENT NEGRO BAJA", categoria: "silleria-ejecutiva", imagen: "/images/productos/fent-baja.jpg", nuevo: false, destacado: true, descripcion: "Versión media de la línea Fent con diseño sofisticado" },
  { id: 9, nombre: "SOLU ALTA", categoria: "silleria-ejecutiva", imagen: "/images/productos/solu-alta.jpg", nuevo: false, destacado: true, descripcion: "Silla ejecutiva con tecnología de soporte avanzado" },
  { id: 10, nombre: "SOLU BAJA", categoria: "silleria-ejecutiva", imagen: "/images/productos/solu-baja.jpg", nuevo: false, destacado: true, descripcion: "Confort y estilo para largas jornadas de trabajo" },
  
  // SILLERÍA OPERATIVA
  { id: 11, nombre: "ZEN BAJA", categoria: "silleria-operativa", imagen: "/images/productos/zen-baja.jpg", nuevo: false, destacado: true, descripcion: "Silla operativa con diseño minimalista y funcional" },
  { id: 12, nombre: "ZEN VISITA", categoria: "silleria-operativa", imagen: "/images/productos/zen-visita.jpg", nuevo: false, destacado: true, descripcion: "Silla para visitantes de la línea Zen" },
  { id: 13, nombre: "ZEN PLUS BAJA", categoria: "silleria-operativa", imagen: "/images/productos/zen-plus-baja.jpg", nuevo: false, destacado: true, descripcion: "Versión mejorada con mayor soporte lumbar" },
  { id: 14, nombre: "ZEN PLUS VISITA", categoria: "silleria-operativa", imagen: "/images/productos/zen-plus-visita.jpg", nuevo: false, destacado: true, descripcion: "Silla de visita con acabados premium" },
  { id: 15, nombre: "NEVA", categoria: "silleria-operativa", imagen: "/images/productos/neva.jpg", nuevo: true, destacado: true, descripcion: "Nueva línea operativa con diseño contemporáneo" },
  { id: 16, nombre: "NANO", categoria: "silleria-operativa", imagen: "/images/productos/nano.jpg", nuevo: false, destacado: true, descripcion: "Silla compacta ideal para espacios reducidos" },
  { id: 17, nombre: "NEZO TAPIZADA", categoria: "silleria-operativa", imagen: "/images/productos/nezo-tapizada.jpg", nuevo: false, destacado: true, descripcion: "Silla operativa con tapizado de alta calidad" },
  { id: 18, nombre: "ERGO BAJA", categoria: "silleria-operativa", imagen: "/images/productos/ergo-baja.jpg", nuevo: false, destacado: true, descripcion: "Diseño ergonómico para máximo confort" },
  
  // SILLERÍA INDUSTRIAL
  { id: 19, nombre: "BANCO INDUSTRIAL CAJERO", categoria: "silleria-industrial", imagen: "/images/productos/banco-cajero.jpg", nuevo: true, destacado: true, descripcion: "Banco alto para áreas de trabajo industrial" },
  { id: 20, nombre: "BANCO INDUSTRIAL BAJO", categoria: "silleria-industrial", imagen: "/images/productos/banco-bajo.jpg", nuevo: true, destacado: true, descripcion: "Banco industrial de altura estándar" },
  { id: 21, nombre: "SILLA INDUSTRIAL BAJA", categoria: "silleria-industrial", imagen: "/images/productos/silla-industrial-baja.jpg", nuevo: true, destacado: true, descripcion: "Silla resistente para entornos industriales" },
  { id: 22, nombre: "SILLA INDUSTRIAL CAJERA", categoria: "silleria-industrial", imagen: "/images/productos/silla-industrial-cajera.jpg", nuevo: true, destacado: true, descripcion: "Silla alta industrial con descansapies" },
  
  // SALAS DE ESPERA
  { id: 23, nombre: "BENCH BASIC 3 PLAZAS", categoria: "salas-espera", imagen: "/images/productos/bench-3.jpg", nuevo: true, destacado: true, descripcion: "Banca de espera para 3 personas" },
  { id: 24, nombre: "BENCH BASIC 4 PLAZAS", categoria: "salas-espera", imagen: "/images/productos/bench-4.jpg", nuevo: true, destacado: true, descripcion: "Banca de espera para 4 personas" },
  { id: 25, nombre: "BENCH BASIC TAPIZADO 3 PLAZAS", categoria: "salas-espera", imagen: "/images/productos/bench-tapizado-3.jpg", nuevo: true, destacado: true, descripcion: "Banca tapizada de 3 plazas con máximo confort" },
  { id: 26, nombre: "BENCH BASIC TAPIZADO 4 PLAZAS", categoria: "salas-espera", imagen: "/images/productos/bench-tapizado-4.jpg", nuevo: true, destacado: true, descripcion: "Banca tapizada de 4 plazas premium" },
  
  // MOBILIARIO ESCOLAR
  { id: 27, nombre: "NEZO MESABANCO PLASTICO", categoria: "mobiliario-escolar", imagen: "/images/productos/mesabanco-plastico.jpg", nuevo: false, destacado: true, descripcion: "Mesabanco escolar con asiento de polipropileno" },
  { id: 28, nombre: "NEZO MESABANCO TAPIZADO", categoria: "mobiliario-escolar", imagen: "/images/productos/mesabanco-tapizado.jpg", nuevo: false, destacado: true, descripcion: "Mesabanco escolar con asiento tapizado" },
  
  // MOBILIARIO DE OFICINA
  { id: 29, nombre: "MESA ABATIBLE FOLD", categoria: "mobiliario", imagen: "/images/productos/mesa-fold.jpg", nuevo: false, destacado: true, descripcion: "Mesa plegable para espacios versátiles" },
  { id: 30, nombre: "ESTRUCTURA ZERO 120x60", categoria: "mobiliario", imagen: "/images/productos/estructura-zero.jpg", nuevo: false, destacado: true, descripcion: "Estructura de escritorio modular 120x60cm" },
  { id: 31, nombre: "ESCRITORIO EJECUTIVO", categoria: "mobiliario", imagen: "/images/productos/escritorio-ejecutivo.jpg", nuevo: false, destacado: false, descripcion: "Escritorio ejecutivo con diseño profesional" },
  { id: 32, nombre: "ESCRITORIO EN L", categoria: "mobiliario", imagen: "/images/productos/escritorio-l.jpg", nuevo: false, destacado: false, descripcion: "Escritorio en forma de L para mayor espacio" },
  { id: 33, nombre: "MESA DE JUNTAS", categoria: "mobiliario", imagen: "/images/productos/mesa-juntas.jpg", nuevo: false, destacado: false, descripcion: "Mesa para sala de reuniones" },
  { id: 34, nombre: "ARCHIVERO 4 GAVETAS", categoria: "mobiliario", imagen: "/images/productos/archivero.jpg", nuevo: false, destacado: false, descripcion: "Archivero metálico de 4 gavetas" },
  { id: 35, nombre: "LIBRERO MODULAR", categoria: "mobiliario", imagen: "/images/productos/librero.jpg", nuevo: false, destacado: false, descripcion: "Sistema de almacenamiento modular" },
]

const categorias = [
  { id: "todos", nombre: "Todos los Productos" },
  { id: "silleria-ejecutiva", nombre: "Sillería Ejecutiva" },
  { id: "silleria-operativa", nombre: "Sillería Operativa" },
  { id: "silleria-industrial", nombre: "Sillería Industrial" },
  { id: "salas-espera", nombre: "Salas de Espera" },
  { id: "mobiliario-escolar", nombre: "Mobiliario Escolar" },
  { id: "mobiliario", nombre: "Mobiliario de Oficina" },
  { id: "diseno-3d", nombre: "Diseños 3D" },
]

export default function CatalogoPage() {
  const [busqueda, setBusqueda] = useState("")
  const [categoriaActiva, setCategoriaActiva] = useState("todos")
  const [vistaGrid, setVistaGrid] = useState(true)
  const [mostrarFiltros, setMostrarFiltros] = useState(false)

  const productosFiltrados = useMemo(() => {
    return productos.filter((producto) => {
      const coincideBusqueda = producto.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
                               producto.descripcion.toLowerCase().includes(busqueda.toLowerCase())
      const coincideCategoria = categoriaActiva === "todos" || producto.categoria === categoriaActiva
      return coincideBusqueda && coincideCategoria
    })
  }, [busqueda, categoriaActiva])

  const solicitarInfo = (nombreProducto: string) => {
    const mensaje = `Hola, me interesa obtener más información sobre el producto: ${nombreProducto}`
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensaje)}`, "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero del Catálogo */}
      <section className="pt-32 pb-12 bg-accent text-white">
        <div className="container mx-auto px-4">
          <Link href="/" className="inline-flex items-center gap-2 text-white/70 hover:text-white mb-6 transition-colors">
            <ArrowLeft className="h-4 w-4" />
            Volver al Inicio
          </Link>
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            Catálogo de Productos
          </h1>
          <p className="text-white/80 text-lg max-w-2xl">
            Explora nuestra amplia gama de sillería y mobiliario de oficina. 
            Productos de alta calidad respaldados por GERSA.
          </p>
          <p className="text-primary font-semibold mt-4">
            Distribuidor Autorizado: GERSA
          </p>
        </div>
      </section>

      {/* Barra de Búsqueda y Filtros */}
      <section className="sticky top-[88px] z-40 bg-card border-b border-border py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Búsqueda */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Buscar productos..."
                className="pl-10 bg-background"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
              {busqueda && (
                <button
                  onClick={() => setBusqueda("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-4 w-full md:w-auto">
              {/* Toggle Filtros Mobile */}
              <Button
                variant="outline"
                className="md:hidden"
                onClick={() => setMostrarFiltros(!mostrarFiltros)}
              >
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>

              {/* Vista Grid/List */}
              <div className="flex items-center gap-2 border rounded-lg p-1">
                <button
                  onClick={() => setVistaGrid(true)}
                  className={`p-2 rounded ${vistaGrid ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <Grid className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setVistaGrid(false)}
                  className={`p-2 rounded ${!vistaGrid ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>

              {/* Contador */}
              <span className="text-sm text-muted-foreground whitespace-nowrap">
                {productosFiltrados.length} productos
              </span>
            </div>
          </div>

          {/* Filtros Desktop */}
          <div className={`mt-4 ${mostrarFiltros ? "block" : "hidden md:block"}`}>
            <div className="flex flex-wrap gap-2">
              {categorias.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategoriaActiva(cat.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    categoriaActiva === cat.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  }`}
                >
                  {cat.nombre}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Grid de Productos */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          {productosFiltrados.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-muted-foreground text-lg mb-4">
                No se encontraron productos con los filtros seleccionados.
              </p>
              <Button variant="outline" onClick={() => { setBusqueda(""); setCategoriaActiva("todos"); }}>
                Limpiar filtros
              </Button>
            </div>
          ) : vistaGrid ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {productosFiltrados.map((producto) => (
                <div
                  key={producto.id}
                  className="group bg-card rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-border"
                >
                  {/* Imagen */}
                  <div className="relative aspect-square bg-muted overflow-hidden">
                    <Image
                      src={producto.imagen}
                      alt={producto.nombre}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    
                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-2">
                      {producto.nuevo && (
                        <Badge className="bg-primary text-primary-foreground">Nuevo</Badge>
                      )}
                      {producto.destacado && (
                        <Badge variant="secondary">Destacado</Badge>
                      )}
                    </div>

                    {/* Overlay con botón */}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button
                        onClick={() => solicitarInfo(producto.nombre)}
                        className="bg-primary hover:bg-primary/90 text-primary-foreground"
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Solicitar Info
                      </Button>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <h3 className="font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
                      {producto.nombre}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {producto.descripcion}
                    </p>
                    <div className="mt-3 pt-3 border-t border-border">
                      <button
                        onClick={() => solicitarInfo(producto.nombre)}
                        className="text-primary text-sm font-medium hover:underline flex items-center gap-1"
                      >
                        <MessageCircle className="h-4 w-4" />
                        Contactar para cotizar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {productosFiltrados.map((producto) => (
                <div
                  key={producto.id}
                  className="flex flex-col sm:flex-row gap-4 bg-card rounded-xl p-4 border border-border hover:shadow-md transition-shadow"
                >
                  {/* Imagen */}
                  <div className="relative w-full sm:w-40 h-40 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={producto.imagen}
                      alt={producto.nombre}
                      fill
                      className="object-cover"
                    />
                    {producto.nuevo && (
                      <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground">Nuevo</Badge>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-grow">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-semibold text-lg text-foreground mb-1">
                          {producto.nombre}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          {producto.descripcion}
                        </p>
                        <Badge variant="outline" className="text-xs">
                          {categorias.find(c => c.id === producto.categoria)?.nombre}
                        </Badge>
                      </div>
                      <Button
                        onClick={() => solicitarInfo(producto.nombre)}
                        className="bg-primary hover:bg-primary/90 text-primary-foreground flex-shrink-0"
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Cotizar
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-accent">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            ¿No encuentras lo que buscas?
          </h2>
          <p className="text-white/80 mb-6 max-w-xl mx-auto">
            Contáctanos y te ayudaremos a encontrar el producto perfecto para tu espacio de trabajo.
          </p>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hola, necesito ayuda para encontrar un producto específico.")}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <MessageCircle className="mr-2 h-5 w-5" />
              Contactar Asesor
            </Button>
          </a>
        </div>
      </section>

      <ShippingNote />
      <Footer />
    </div>
  )
}
