"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, Loader2, X, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"
import type { Category, Product } from "@/lib/types"

export default function EditarProductoPage() {
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [categories, setCategories] = useState<Category[]>([])
  const [formData, setFormData] = useState({
    name: "",
    slug: "",
    description: "",
    category_id: "",
    image_url: "",
    features: [""],
    is_new: false,
    is_featured: false,
    is_active: true
  })
  const router = useRouter()
  const params = useParams()
  const supabase = createClient()
  const productId = params.id as string

  useEffect(() => {
    const session = localStorage.getItem("ofi_admin_session")
    if (!session) {
      router.push("/admin")
      return
    }
    setIsAuthorized(true)
    loadData()
  }, [router, productId])

  const loadData = async () => {
    setIsLoading(true)
    
    const [productRes, categoriesRes] = await Promise.all([
      supabase.from("products").select("*").eq("id", productId).single(),
      supabase.from("categories").select("*").order("name")
    ])

    if (productRes.data) {
      const product = productRes.data
      setFormData({
        name: product.name || "",
        slug: product.slug || "",
        description: product.description || "",
        category_id: product.category_id || "",
        image_url: product.image_url || "",
        features: product.features?.length ? product.features : [""],
        is_new: product.is_new || false,
        is_featured: product.is_featured || false,
        is_active: product.is_active ?? true
      })
    }
    if (categoriesRes.data) setCategories(categoriesRes.data)
    
    setIsLoading(false)
  }

  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...formData.features]
    newFeatures[index] = value
    setFormData({ ...formData, features: newFeatures })
  }

  const addFeature = () => {
    setFormData({ ...formData, features: [...formData.features, ""] })
  }

  const removeFeature = (index: number) => {
    const newFeatures = formData.features.filter((_, i) => i !== index)
    setFormData({ ...formData, features: newFeatures.length ? newFeatures : [""] })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    const features = formData.features.filter(f => f.trim() !== "")

    const { error } = await supabase
      .from("products")
      .update({
        name: formData.name,
        slug: formData.slug,
        description: formData.description || null,
        category_id: formData.category_id || null,
        image_url: formData.image_url || null,
        features: features.length > 0 ? features : null,
        is_new: formData.is_new,
        is_featured: formData.is_featured,
        is_active: formData.is_active,
        updated_at: new Date().toISOString()
      })
      .eq("id", productId)

    if (error) {
      alert("Error al actualizar: " + error.message)
    } else {
      router.push("/admin/productos")
    }
    setIsSaving(false)
  }

  const handleDelete = async () => {
    if (!confirm("¿Está seguro de eliminar este producto? Esta acción no se puede deshacer.")) return
    
    const { error } = await supabase.from("products").delete().eq("id", productId)
    
    if (error) {
      alert("Error al eliminar: " + error.message)
    } else {
      router.push("/admin/productos")
    }
  }

  if (!isAuthorized || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin/productos">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
            </Link>
            <h1 className="text-xl font-semibold">Editar Producto</h1>
          </div>
          <Button variant="destructive" size="sm" onClick={handleDelete}>
            <Trash2 className="h-4 w-4 mr-2" />
            Eliminar
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <form onSubmit={handleSubmit}>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Información del Producto</CardTitle>
              <CardDescription>Datos básicos del producto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre del Producto *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="slug">URL Amigable</Label>
                <Input
                  id="slug"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select 
                  value={formData.category_id} 
                  onValueChange={(value) => setFormData({ ...formData, category_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descripción</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="image_url">URL de Imagen</Label>
                <Input
                  id="image_url"
                  value={formData.image_url}
                  onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                />
                {formData.image_url && (
                  <div className="mt-2">
                    <img 
                      src={formData.image_url} 
                      alt="Preview" 
                      className="w-32 h-32 object-cover rounded-lg border"
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Características</CardTitle>
              <CardDescription>Lista de características del producto</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {formData.features.map((feature, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    value={feature}
                    onChange={(e) => handleFeatureChange(index, e.target.value)}
                    placeholder={`Característica ${index + 1}`}
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon"
                    onClick={() => removeFeature(index)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button type="button" variant="outline" onClick={addFeature}>
                Agregar Característica
              </Button>
            </CardContent>
          </Card>

          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Opciones</CardTitle>
              <CardDescription>Configuración de visibilidad</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Producto Activo</Label>
                  <p className="text-sm text-muted-foreground">El producto se mostrará en el catálogo</p>
                </div>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Marcar como Nuevo</Label>
                  <p className="text-sm text-muted-foreground">Mostrará una etiqueta de "Nuevo"</p>
                </div>
                <Switch
                  checked={formData.is_new}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_new: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Producto Destacado</Label>
                  <p className="text-sm text-muted-foreground">Aparecerá en la página de inicio</p>
                </div>
                <Switch
                  checked={formData.is_featured}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_featured: checked })}
                />
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Link href="/admin/productos" className="flex-1">
              <Button type="button" variant="outline" className="w-full">
                Cancelar
              </Button>
            </Link>
            <Button 
              type="submit" 
              className="flex-1 bg-primary hover:bg-primary/90"
              disabled={isSaving || !formData.name}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Guardando...
                </>
              ) : (
                "Guardar Cambios"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
