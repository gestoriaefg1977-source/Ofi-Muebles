"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { 
  LayoutDashboard, 
  Package, 
  FolderOpen, 
  Tag, 
  LogOut,
  Plus,
  Edit,
  Trash2,
  Search,
  ChevronRight,
  Loader2
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import type { Product, Category, Offer } from "@/lib/types"

export default function AdminDashboard() {
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [offers, setOffers] = useState<Offer[]>([])
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const session = localStorage.getItem("ofi_admin_session")
    if (!session) {
      router.push("/admin")
      return
    }
    
    // Verificar que la sesión no tenga más de 24 horas
    const sessionTime = parseInt(session)
    if (Date.now() - sessionTime > 24 * 60 * 60 * 1000) {
      localStorage.removeItem("ofi_admin_session")
      router.push("/admin")
      return
    }

    setIsAuthorized(true)
    loadData()
  }, [router])

  const loadData = async () => {
    setIsLoading(true)
    
    const [productsRes, categoriesRes, offersRes] = await Promise.all([
      supabase.from("products").select("*, category:categories(*)").order("created_at", { ascending: false }),
      supabase.from("categories").select("*").order("name"),
      supabase.from("offers").select("*, product:products(*)").order("created_at", { ascending: false })
    ])

    if (productsRes.data) setProducts(productsRes.data)
    if (categoriesRes.data) setCategories(categoriesRes.data)
    if (offersRes.data) setOffers(offersRes.data)
    
    setIsLoading(false)
  }

  const handleLogout = () => {
    localStorage.removeItem("ofi_admin_session")
    router.push("/admin")
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo%20OFI-MUEBLES-PW-01-NEGRO-F26q6xgWLtF0JEOu1VPyY5hAfxtt62.png"
              alt="OFI-MUEBLES"
              width={150}
              height={60}
              className="h-10 w-auto"
            />
            <span className="text-sm text-muted-foreground border-l pl-4">Panel de Administrador</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary">
              Ver Sitio
            </Link>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Cerrar Sesión
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Productos</CardDescription>
              <CardTitle className="text-3xl">{products.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <Link href="/admin/productos" className="text-sm text-primary hover:underline flex items-center">
                Ver todos <ChevronRight className="h-4 w-4" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Categorías</CardDescription>
              <CardTitle className="text-3xl">{categories.length}</CardTitle>
            </CardHeader>
            <CardContent>
              <Link href="/admin/categorias" className="text-sm text-primary hover:underline flex items-center">
                Ver todas <ChevronRight className="h-4 w-4" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Ofertas Activas</CardDescription>
              <CardTitle className="text-3xl">{offers.filter(o => o.is_active).length}</CardTitle>
            </CardHeader>
            <CardContent>
              <Link href="/admin/ofertas" className="text-sm text-primary hover:underline flex items-center">
                Ver todas <ChevronRight className="h-4 w-4" />
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Productos Destacados</CardDescription>
              <CardTitle className="text-3xl">{products.filter(p => p.is_featured).length}</CardTitle>
            </CardHeader>
            <CardContent>
              <span className="text-sm text-muted-foreground">Mostrados en inicio</span>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => router.push("/admin/productos/nuevo")}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <Plus className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Agregar Producto</h3>
                  <p className="text-sm text-muted-foreground">Crear nuevo producto en el catálogo</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => router.push("/admin/ofertas/nueva")}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-green-500/10 rounded-lg">
                  <Tag className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <h3 className="font-semibold">Crear Oferta</h3>
                  <p className="text-sm text-muted-foreground">Agregar promoción o descuento</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => router.push("/admin/categorias")}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-500/10 rounded-lg">
                  <FolderOpen className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-semibold">Gestionar Categorías</h3>
                  <p className="text-sm text-muted-foreground">Administrar categorías de productos</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Products */}
        <Card className="mb-8">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Productos Recientes</CardTitle>
              <CardDescription>Últimos productos agregados al catálogo</CardDescription>
            </div>
            <Link href="/admin/productos">
              <Button variant="outline" size="sm">Ver Todos</Button>
            </Link>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="space-y-4">
                {products.slice(0, 5).map((product) => (
                  <div key={product.id} className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                    <div className="w-16 h-16 bg-muted rounded-lg overflow-hidden flex-shrink-0">
                      {product.image_url ? (
                        <img 
                          src={product.image_url} 
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="h-6 w-6 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium truncate">{product.name}</h4>
                      <p className="text-sm text-muted-foreground truncate">
                        {product.category?.name || "Sin categoría"}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {product.is_new && (
                        <span className="text-xs bg-green-500/10 text-green-600 px-2 py-1 rounded">Nuevo</span>
                      )}
                      {product.is_featured && (
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">Destacado</span>
                      )}
                      <Link href={`/admin/productos/${product.id}`}>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Offers */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Ofertas Activas</CardTitle>
              <CardDescription>Promociones y descuentos vigentes</CardDescription>
            </div>
            <Link href="/admin/ofertas">
              <Button variant="outline" size="sm">Ver Todas</Button>
            </Link>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : offers.filter(o => o.is_active).length === 0 ? (
              <div className="text-center py-8">
                <Tag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No hay ofertas activas</p>
                <Link href="/admin/ofertas/nueva">
                  <Button className="mt-4" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Crear Oferta
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {offers.filter(o => o.is_active).slice(0, 5).map((offer) => (
                  <div key={offer.id} className="flex items-center gap-4 p-4 bg-green-500/5 border border-green-500/20 rounded-lg">
                    <div className="p-2 bg-green-500/10 rounded-lg">
                      <Tag className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium">{offer.title}</h4>
                      <p className="text-sm text-muted-foreground">
                        {offer.product?.name || "Oferta general"}
                        {offer.discount_percentage && ` - ${offer.discount_percentage}% descuento`}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs bg-green-500 text-white px-2 py-1 rounded">
                        {offer.badge_text}
                      </span>
                      <Link href={`/admin/ofertas/${offer.id}`}>
                        <Button variant="ghost" size="sm">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
