"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Lock, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

const ADMIN_PIN = "perla1979*"

export default function AdminLoginPage() {
  const [pin, setPin] = useState("")
  const [showPin, setShowPin] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simular delay para seguridad
    await new Promise(resolve => setTimeout(resolve, 500))

    if (pin === ADMIN_PIN) {
      // Guardar sesión en localStorage
      localStorage.setItem("ofi_admin_session", Date.now().toString())
      router.push("/admin/dashboard")
    } else {
      setError("PIN incorrecto. Intente nuevamente.")
      setPin("")
    }
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-muted flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo%20OFI-MUEBLES-PW-01-NEGRO-F26q6xgWLtF0JEOu1VPyY5hAfxtt62.png"
              alt="OFI-MUEBLES"
              width={200}
              height={80}
              className="h-16 w-auto mx-auto"
            />
          </div>
          <CardTitle className="text-2xl font-bold text-foreground">Panel de Administrador</CardTitle>
          <CardDescription>Ingrese su PIN de acceso para continuar</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="pin" className="text-sm font-medium text-foreground">
                PIN de Acceso
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="pin"
                  type={showPin ? "text" : "password"}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Contraseña"
                  className="pl-10 pr-10 text-center tracking-wider"
                  autoComplete="off"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPin ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="text-sm text-destructive text-center bg-destructive/10 py-2 rounded-md">
                {error}
              </div>
            )}

            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90"
              disabled={pin.length === 0 || isLoading}
            >
              {isLoading ? "Verificando..." : "Ingresar"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <a href="/" className="text-sm text-muted-foreground hover:text-primary">
              Volver al sitio
            </a>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
