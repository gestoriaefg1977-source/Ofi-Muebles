"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { 
  Plus,
  Edit,
  Trash2,
  Tag,
  Loader2,
  ArrowLeft,
  MoreVertical,
  Eye,
  EyeOff,
  Calendar
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { createClient } from "@/lib/supabase/client"
import type { Offer } from "@/lib/types"

export default function OfertasAdminPage() {
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [offers, setOffers] = useState<Offer[]>([])
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const session = localStorage.getItem("ofi_admin_session")
    if (!session) {
      router.push("/admin")
      return
    }
    setIsAuthorized(true)
    loadOffers()
  }, [router])

  const loadOffers = async () => {
    setIsLoading(true)
    
    const { data } = await supabase
      .from("offers")
      .select("*, product:products(*)")
      .order("created_at", { ascending: false })

    if (data) setOffers(data)
    setIsLoading(false)
  }

  const toggleActive = async (offer: Offer) => {
    const { error } = await supabase
      .from("offers")
      .update({ is_active: !offer.is_active })
      .eq("id", offer.id)
    
    if (!error) {
      setOffers(offers.map(o => 
        o.id === offer.id ? { ...o, is_active: !o.is_active } : o
      ))
    }
  }

  const deleteOffer = async (id: string) => {
    if (!confirm("¿Está seguro de eliminar esta oferta?")) return
    
    const { error } = await supabase.from("offers").delete().eq("id", id)
    
    if (!error) {
      setOffers(offers.filter(o => o.id !== id))
    }
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Sin fecha"
    return new Date(dateString).toLocaleDateString("es-MX", {
      day: "numeric",
      month: "short",
      year: "numeric"
    })
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted">
      {/* Header */}
      <header className="bg-background border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
            </Link>
            <h1 className="text-xl font-semibold">Gestión de Ofertas</h1>
          </div>
          <Link href="/admin/ofertas/nueva">
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Oferta
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Ofertas y Promociones ({offers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : offers.length === 0 ? (
              <div className="text-center py-8">
                <Tag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No hay ofertas creadas</p>
                <Link href="/admin/ofertas/nueva">
                  <Button className="mt-4" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Crear Primera Oferta
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {offers.map((offer) => (
                  <div 
                    key={offer.id} 
                    className={`flex items-center gap-4 p-4 rounded-lg border ${
                      offer.is_active 
                        ? "bg-green-500/5 border-green-500/20" 
                        : "bg-muted/50 border-border"
                    }`}
                  >
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Tag className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{offer.title}</h4>
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          offer.is_active 
                            ? "bg-green-500 text-white" 
                            : "bg-muted text-muted-foreground"
                        }`}>
                          {offer.badge_text}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {offer.product?.name || "Oferta general"}
                        {offer.discount_percentage && ` - ${offer.discount_percentage}% descuento`}
                      </p>
                      <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Inicio: {formatDate(offer.start_date)}
                        </span>
                        {offer.end_date && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Fin: {formatDate(offer.end_date)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => toggleActive(offer)}>
                        {offer.is_active ? (
                          <span className="inline-flex items-center gap-1 text-xs bg-green-500/10 text-green-600 px-2 py-1 rounded">
                            <Eye className="h-3 w-3" /> Activa
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs bg-red-500/10 text-red-600 px-2 py-1 rounded">
                            <EyeOff className="h-3 w-3" /> Inactiva
                          </span>
                        )}
                      </button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => router.push(`/admin/ofertas/${offer.id}`)}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => deleteOffer(offer.id)}
                            className="text-red-600"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
