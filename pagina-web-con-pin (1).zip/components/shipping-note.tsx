import { Truck, Clock, MapPin, Info } from "lucide-react"

export function ShippingNote() {
  return (
    <section className="py-8 bg-primary/5 border-y border-primary/10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-center md:text-left">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Truck className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-foreground">Tiempos de Embarque</p>
              <p className="text-sm text-muted-foreground">
                Sillería: 1-2 días | Mobiliario en stock: 1-3 días | Fabricación: 15-25 días
              </p>
            </div>
          </div>
          
          <div className="hidden md:block w-px h-12 bg-border" />
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center">
              <Info className="h-6 w-6 text-amber-600" />
            </div>
            <div>
              <p className="font-semibold text-foreground">Nota Importante</p>
              <p className="text-sm text-muted-foreground">
                Precio sujeto a flete según área metropolitana
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
