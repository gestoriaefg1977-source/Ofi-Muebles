import { Truck, Clock, Shield, Headphones } from "lucide-react"

const features = [
  {
    icon: Truck,
    title: "Entrega Rápida",
    description: "Sillería de 1-2 días. Mobiliario en stock de 1-3 días. Fabricación especial de 15-25 días."
  },
  {
    icon: Clock,
    title: "Experiencia",
    description: "Más de 15 años distribuyendo muebles de oficina de la más alta calidad en México."
  },
  {
    icon: Shield,
    title: "Garantía",
    description: "Todos nuestros productos cuentan con garantía de fábrica y soporte técnico."
  },
  {
    icon: Headphones,
    title: "Asesoría",
    description: "Equipo de expertos para ayudarte a elegir el mobiliario ideal para tu espacio."
  }
]

export function Features() {
  return (
    <section className="py-16 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="flex flex-col items-center text-center p-6 rounded-lg hover:bg-secondary transition-colors"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <feature.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
