import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

const categories = [
  {
    id: 1,
    name: "Sillería Ejecutiva",
    description: "Sillas de alta gama para directivos y ejecutivos",
    image: "/images/productos/bolt-alta.jpg",
    count: "10+ modelos",
    href: "/catalogo?categoria=silleria-ejecutiva"
  },
  {
    id: 2,
    name: "Sillería Operativa",
    description: "Comodidad y ergonomía para el trabajo diario",
    image: "/images/productos/neva.jpg",
    count: "8+ modelos",
    href: "/catalogo?categoria=silleria-operativa"
  },
  {
    id: 3,
    name: "Sillería Industrial",
    description: "Resistencia y durabilidad para entornos de trabajo",
    image: "/images/productos/banco-cajero.jpg",
    count: "4+ modelos",
    href: "/catalogo?categoria=silleria-industrial"
  },
  {
    id: 4,
    name: "Salas de Espera",
    description: "Bancas y asientos para áreas de recepción",
    image: "/images/productos/bench-tapizado-4.jpg",
    count: "4+ modelos",
    href: "/catalogo?categoria=salas-espera"
  },
  {
    id: 5,
    name: "Mobiliario de Oficina",
    description: "Escritorios, mesas y almacenamiento",
    image: "/images/productos/escritorio-ejecutivo.jpg",
    count: "7+ modelos",
    href: "/catalogo?categoria=mobiliario"
  },
  {
    id: 6,
    name: "Diseños 3D",
    description: "Proyectos personalizados para tus espacios",
    image: "/images/diseno-3d.jpg",
    count: "Proyectos a medida",
    href: "/#diseno-3d"
  },
]

export function Categories() {
  return (
    <section id="categorias" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            Explora Nuestras Líneas
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            Categorías de Productos
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Encuentra la solución perfecta para cada área de tu oficina. 
            Productos respaldados por GERSA.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={category.href}
              className="group relative overflow-hidden rounded-xl h-64 block"
            >
              <Image
                src={category.image}
                alt={category.name}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-accent via-accent/50 to-transparent" />
              
              <div className="absolute inset-0 p-6 flex flex-col justify-end">
                <span className="text-primary text-sm font-medium mb-1">
                  {category.count}
                </span>
                <h3 className="text-xl font-bold text-white mb-2">
                  {category.name}
                </h3>
                <p className="text-white/80 text-sm mb-4">
                  {category.description}
                </p>
                <div className="flex items-center text-primary font-medium group-hover:gap-3 gap-2 transition-all">
                  <span>Ver productos</span>
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
