"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin, Clock, Send, MessageCircle } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

const contactInfo = [
  {
    icon: Phone,
    title: "Teléfono",
    details: ["81 4391 0283"],
    href: "tel:+528143910283"
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    details: ["81 1953 0718"],
    href: `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hola, me interesa obtener información sobre sus productos.")}`
  },
  {
    icon: Mail,
    title: "Email",
    details: ["ofimuebles77@gmail.com"],
    href: "mailto:ofimuebles77@gmail.com"
  },
  {
    icon: MapPin,
    title: "Dirección",
    details: ["Av. De Las Industrias 502", "Parque Industrial Escobedo", "66062 Cdad. Gral. Escobedo, N.L."],
    href: "https://maps.google.com/?q=Av.+De+Las+Industrias+502,+Parque+Industrial+Escobedo,+66062+Cdad.+Gral.+Escobedo,+N.L.,+México"
  },
  {
    icon: Clock,
    title: "Horario",
    details: ["Lun - Vie: 9:00 - 18:00", "Sáb: 9:00 - 14:00"],
    href: null
  },
]

export function Contact() {
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    telefono: "",
    empresa: "",
    mensaje: ""
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    const whatsappMessage = `*Nueva Solicitud de Contacto*%0A%0A*Nombre:* ${formData.nombre}%0A*Email:* ${formData.email}%0A*Teléfono:* ${formData.telefono}%0A*Empresa:* ${formData.empresa}%0A*Mensaje:* ${formData.mensaje}`
    
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${whatsappMessage}`, "_blank")
  }

  return (
    <section id="contacto" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            Contáctanos
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            Estamos Aquí para Ayudarte
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Envíanos un mensaje y uno de nuestros asesores se pondrá en contacto 
            contigo a la brevedad
          </p>
          <p className="text-sm text-primary font-medium mt-2">
            Distribuidor Autorizado: GERSA
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="space-y-4">
            {contactInfo.map((info, index) => (
              <a
                key={index}
                href={info.href || undefined}
                target={info.href?.startsWith("http") ? "_blank" : undefined}
                rel={info.href?.startsWith("http") ? "noopener noreferrer" : undefined}
                className={`flex gap-4 p-4 bg-card rounded-lg ${info.href ? "hover:bg-card/80 cursor-pointer transition-colors" : ""}`}
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <info.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-1">{info.title}</h4>
                  {info.details.map((detail, i) => (
                    <p key={i} className="text-sm text-muted-foreground">{detail}</p>
                  ))}
                </div>
              </a>
            ))}
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-card p-8 rounded-xl shadow-sm">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Nombre completo
                  </label>
                  <Input 
                    placeholder="Tu nombre" 
                    className="bg-background"
                    value={formData.nombre}
                    onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Email
                  </label>
                  <Input 
                    type="email" 
                    placeholder="tu@email.com" 
                    className="bg-background"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    required
                  />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Teléfono
                  </label>
                  <Input 
                    placeholder="81 1234 5678" 
                    className="bg-background"
                    value={formData.telefono}
                    onChange={(e) => setFormData({...formData, telefono: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Empresa
                  </label>
                  <Input 
                    placeholder="Nombre de tu empresa" 
                    className="bg-background"
                    value={formData.empresa}
                    onChange={(e) => setFormData({...formData, empresa: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Mensaje
                </label>
                <Textarea 
                  placeholder="Cuéntanos sobre tu proyecto o los productos que te interesan..." 
                  rows={5}
                  className="bg-background resize-none"
                  value={formData.mensaje}
                  onChange={(e) => setFormData({...formData, mensaje: e.target.value})}
                  required
                />
              </div>
              
              <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                <Send className="mr-2 h-5 w-5" />
                Enviar por WhatsApp
              </Button>
              
              <p className="text-xs text-muted-foreground text-center mt-4">
                Al enviar, serás redirigido a WhatsApp con tu mensaje pre-llenado
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
