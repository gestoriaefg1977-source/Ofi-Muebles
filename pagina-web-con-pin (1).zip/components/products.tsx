"use client"

import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, ArrowRight } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

const products = [
  {
    id: 1,
    name: "BOLT ALTA",
    category: "Sillería Ejecutiva",
    image: "/images/productos/bolt-alta.jpg",
    badge: "Nuevo",
    badgeColor: "bg-primary",
    descripcion: "Silla ejecutiva de respaldo alto con diseño moderno"
  },
  {
    id: 2,
    name: "NEVA",
    category: "Sillería Operativa",
    image: "/images/productos/neva.jpg",
    badge: "Nuevo",
    badgeColor: "bg-primary",
    descripcion: "Nueva línea operativa con diseño contemporáneo"
  },
  {
    id: 3,
    name: "MESA ABATIBLE FOLD",
    category: "Mobiliario",
    image: "/images/productos/mesa-fold.jpg",
    badge: "Destacado",
    badgeColor: "bg-accent",
    descripcion: "Mesa plegable para espacios versátiles"
  },
  {
    id: 4,
    name: "BENCH BASIC TAPIZADO",
    category: "Salas de Espera",
    image: "/images/productos/bench-tapizado-4.jpg",
    badge: "Nuevo",
    badgeColor: "bg-primary",
    descripcion: "Banca tapizada de alta calidad"
  },
]

export function Products() {
  const solicitarInfo = (nombreProducto: string) => {
    const mensaje = `Hola, me interesa obtener más información sobre el producto: ${nombreProducto}`
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensaje)}`, "_blank")
  }

  return (
    <section id="productos" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">
            Nuestro Catálogo
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
            Productos Destacados
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explora nuestra selección de muebles de oficina de alta calidad, 
            diseñados para ofrecer confort, estilo y durabilidad.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-card rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300"
            >
              <div className="relative aspect-square overflow-hidden bg-secondary">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <Badge className={`absolute top-3 left-3 ${product.badgeColor} text-white`}>
                  {product.badge}
                </Badge>
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-accent/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                  <Button 
                    onClick={() => solicitarInfo(product.name)}
                    className="bg-primary hover:bg-primary/90"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Cotizar
                  </Button>
                </div>
              </div>
              
              <div className="p-4">
                <span className="text-xs text-primary font-medium uppercase tracking-wider">
                  {product.category}
                </span>
                <h3 className="font-semibold text-foreground mt-1 group-hover:text-primary transition-colors">
                  {product.name}
                </h3>
                <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                  {product.descripcion}
                </p>
                <button 
                  onClick={() => solicitarInfo(product.name)}
                  className="text-sm text-primary hover:underline mt-3 flex items-center gap-1"
                >
                  <MessageCircle className="h-4 w-4" />
                  Solicitar información
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/catalogo">
            <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
              Ver Catálogo Completo
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
