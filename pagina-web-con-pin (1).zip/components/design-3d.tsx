"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { MessageCircle, Ruler, Lightbulb, PenTool, CheckCircle, ChevronLeft, ChevronRight, Eye, X } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

const features = [
  {
    icon: Ruler,
    title: "Medición de Espacios",
    description: "Análisis detallado de las dimensiones y características de tu espacio de trabajo"
  },
  {
    icon: Lightbulb,
    title: "Propuesta de Diseño",
    description: "Conceptualización creativa basada en tus necesidades y estilo corporativo"
  },
  {
    icon: PenTool,
    title: "Modelado 3D",
    description: "Visualización realista de tu oficina antes de realizar cualquier inversión"
  },
  {
    icon: CheckCircle,
    title: "Implementación",
    description: "Ejecución del proyecto con productos de la más alta calidad"
  }
]

// Galería de diseños realizados
const designGallery = [
  {
    id: 1,
    title: "Oficina Ejecutiva Moderna",
    description: "Diseño contemporáneo con espacios amplios y mobiliario ergonómico",
    image: "/images/diseno-3d.jpg"
  },
  {
    id: 2,
    title: "Sala de Juntas Premium",
    description: "Ambiente profesional para reuniones de alto nivel",
    image: "/images/sala-juntas.jpg"
  },
  {
    id: 3,
    title: "Open Office Corporativo",
    description: "Espacios colaborativos con estaciones de trabajo eficientes",
    image: "/images/hero-office.jpg"
  },
  {
    id: 4,
    title: "Recepción Empresarial",
    description: "Primera impresión impactante para tus visitantes",
    image: "/images/productos/bolt-alta.jpg"
  },
  {
    id: 5,
    title: "Área de Descanso",
    description: "Espacios de bienestar para tus colaboradores",
    image: "/images/productos/bench-tapizado-4.jpg"
  }
]

export function Design3D() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)
  const [showGallery, setShowGallery] = useState(false)
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hola, me interesa solicitar un proyecto de diseño 3D para mis espacios de oficina.")}`

  // Auto-rotate carousel
  useEffect(() => {
    if (!isAutoPlaying || showGallery) return
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % designGallery.length)
    }, 4000)

    return () => clearInterval(interval)
  }, [isAutoPlaying, showGallery])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % designGallery.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + designGallery.length) % designGallery.length)
  }

  const openImageViewer = (index: number) => {
    setSelectedImage(index)
  }

  return (
    <section id="diseno-3d" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <div>
            <span className="inline-block bg-primary/20 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
              Servicio Exclusivo
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              Diseños Realizados en 3D
            </h2>
            
            <p className="text-muted-foreground leading-relaxed mb-6">
              Transformamos tu visión en realidad. Nuestro equipo de diseño especializado 
              desarrolla proyectos personalizados en 3D para optimizar y visualizar tus 
              espacios de trabajo antes de implementarlos.
            </p>

            <p className="text-foreground font-medium mb-8">
              Realizamos proyectos de diseño para desarrollar sus espacios de oficina 
              con visualizaciones fotorrealistas que le permitirán tomar las mejores 
              decisiones para su inversión.
            </p>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3 p-4 bg-card rounded-lg">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">{feature.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto">
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Contactar con un Asesor
                </Button>
              </a>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground w-full sm:w-auto"
                onClick={() => setShowGallery(true)}
              >
                <Eye className="mr-2 h-5 w-5" />
                Ver Más Diseños
              </Button>
            </div>
          </div>

          {/* Image Carousel Side */}
          <div className="relative">
            <div 
              className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl"
              onMouseEnter={() => setIsAutoPlaying(false)}
              onMouseLeave={() => setIsAutoPlaying(true)}
            >
              {/* Carousel Images */}
              {designGallery.map((design, index) => (
                <div
                  key={design.id}
                  className={`absolute inset-0 transition-opacity duration-700 ${
                    index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
                  }`}
                >
                  <Image
                    src={design.image}
                    alt={design.title}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-accent/80 via-transparent to-transparent" />
                </div>
              ))}
              
              {/* Navigation Arrows */}
              <button
                onClick={prevSlide}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/90 hover:bg-white flex items-center justify-center shadow-lg transition-all"
                aria-label="Anterior"
              >
                <ChevronLeft className="h-6 w-6 text-accent" />
              </button>
              <button
                onClick={nextSlide}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/90 hover:bg-white flex items-center justify-center shadow-lg transition-all"
                aria-label="Siguiente"
              >
                <ChevronRight className="h-6 w-6 text-accent" />
              </button>

              {/* Floating Badge */}
              <div className="absolute bottom-6 left-6 right-6 z-20">
                <div className="bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg">
                  <p className="text-foreground font-semibold text-lg">
                    {designGallery[currentSlide].title}
                  </p>
                  <p className="text-muted-foreground text-sm">
                    {designGallery[currentSlide].description}
                  </p>
                </div>
              </div>

              {/* Dots Indicator */}
              <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 flex gap-2">
                {designGallery.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-2.5 h-2.5 rounded-full transition-all ${
                      index === currentSlide 
                        ? "bg-primary w-8" 
                        : "bg-white/60 hover:bg-white"
                    }`}
                    aria-label={`Ir al diseño ${index + 1}`}
                  />
                ))}
              </div>
            </div>

            {/* Decorative Elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary/20 rounded-full blur-2xl" />
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-primary/10 rounded-full blur-2xl" />
          </div>
        </div>
      </div>

      {/* Gallery Modal */}
      <Dialog open={showGallery} onOpenChange={setShowGallery}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Galería de Diseños 3D</DialogTitle>
            <DialogDescription>
              Explora nuestros proyectos de diseño realizados para distintas empresas
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
            {designGallery.map((design, index) => (
              <div 
                key={design.id}
                className="group relative aspect-video rounded-lg overflow-hidden cursor-pointer"
                onClick={() => openImageViewer(index)}
              >
                <Image
                  src={design.image}
                  alt={design.title}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform">
                  <p className="text-white font-semibold text-sm">{design.title}</p>
                  <p className="text-white/80 text-xs">{design.description}</p>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center">
                    <Eye className="h-6 w-6 text-accent" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center gap-4 mt-6">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button className="bg-primary hover:bg-primary/90">
                <MessageCircle className="mr-2 h-4 w-4" />
                Solicitar Proyecto Personalizado
              </Button>
            </a>
          </div>
        </DialogContent>
      </Dialog>

      {/* Image Viewer Modal */}
      <Dialog open={selectedImage !== null} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-5xl p-0 overflow-hidden bg-black/95">
          <button 
            onClick={() => setSelectedImage(null)}
            className="absolute top-4 right-4 z-50 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
          >
            <X className="h-6 w-6 text-white" />
          </button>
          
          {selectedImage !== null && (
            <div className="relative aspect-video w-full">
              <Image
                src={designGallery[selectedImage].image}
                alt={designGallery[selectedImage].title}
                fill
                className="object-contain"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent">
                <p className="text-white font-semibold text-xl">
                  {designGallery[selectedImage].title}
                </p>
                <p className="text-white/80">
                  {designGallery[selectedImage].description}
                </p>
              </div>
            </div>
          )}
          
          {/* Navigation in viewer */}
          {selectedImage !== null && (
            <>
              <button
                onClick={() => setSelectedImage((prev) => prev !== null ? (prev - 1 + designGallery.length) % designGallery.length : 0)}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
              >
                <ChevronLeft className="h-8 w-8 text-white" />
              </button>
              <button
                onClick={() => setSelectedImage((prev) => prev !== null ? (prev + 1) % designGallery.length : 0)}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
              >
                <ChevronRight className="h-8 w-8 text-white" />
              </button>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}
