import Image from "next/image"
import Link from "next/link"
import { Facebook, Instagram, MessageCircle, Settings } from "lucide-react"

const quickLinks = [
  { href: "/", label: "Inicio" },
  { href: "/catalogo", label: "Catálogo" },
  { href: "/#categorias", label: "Categorías" },
  { href: "/#nosotros", label: "Nosotros" },
  { href: "/#contacto", label: "Contacto" },
  { href: "/admin", label: "Administrador" },
]

const productLinks = [
  { href: "/catalogo?categoria=silleria-ejecutiva", label: "Sillería Ejecutiva" },
  { href: "/catalogo?categoria=silleria-operativa", label: "Sillería Operativa" },
  { href: "/catalogo?categoria=silleria-industrial", label: "Sillería Industrial" },
  { href: "/catalogo?categoria=mobiliario", label: "Mobiliario" },
  { href: "/catalogo?categoria=salas-espera", label: "Salas de Espera" },
]

const WHATSAPP_NUMBER = "528119530718"

const socialLinks = [
  { icon: Facebook, href: "#", label: "Facebook" },
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: MessageCircle, href: `https://wa.me/${WHATSAPP_NUMBER}`, label: "WhatsApp" },
]

export function Footer() {
  return (
    <footer className="bg-accent text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div>
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Logo%20OFI-MUEBLES-PW-01-NEGRO-F26q6xgWLtF0JEOu1VPyY5hAfxtt62.png"
              alt="OFI-MUEBLES"
              width={150}
              height={50}
              className="h-12 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-white/70 text-sm leading-relaxed mb-4">
              Distribuidor autorizado de muebles de oficina. Transformamos espacios 
              de trabajo en ambientes productivos y confortables.
            </p>
            <p className="text-primary font-semibold text-sm mb-6">
              Distribuidor Autorizado: GERSA
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith("http") ? "_blank" : undefined}
                  rel={social.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-primary transition-colors"
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link 
                    href={link.href}
                    className="text-white/70 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Productos</h4>
            <ul className="space-y-3">
              {productLinks.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href}
                    className="text-white/70 hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-lg mb-4">Contacto</h4>
            <ul className="space-y-3 text-sm text-white/70">
              <li>
                <strong className="text-white">Ubícanos:</strong><br />
                Av. De Las Industrias 502<br />
                Parque Industrial Escobedo<br />
                66062 Cdad. Gral. Escobedo, N.L., México
              </li>
              <li>
                <strong className="text-white">Teléfono:</strong><br />
                <a href="tel:+528143910283" className="hover:text-primary transition-colors">81 4391 0283</a>
              </li>
              <li>
                <strong className="text-white">WhatsApp:</strong><br />
                <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">81 1953 0718</a>
              </li>
              <li>
                <strong className="text-white">Email:</strong><br />
                <a href="mailto:ofimuebles77@gmail.com" className="hover:text-primary transition-colors">ofimuebles77@gmail.com</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-white/60">
            <p>© 2024 OFI-MUEBLES. Todos los derechos reservados.</p>
            <div className="flex items-center gap-4">
              <p className="text-primary">Distribuidor Autorizado: GERSA</p>
              <Link 
                href="/admin" 
                className="flex items-center gap-1.5 text-white/40 hover:text-primary transition-colors text-xs"
              >
                <Settings className="h-3.5 w-3.5" />
                <span>Admin</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
