import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Phone, ArrowRight, MessageCircle } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"
const WHATSAPP_MESSAGE = "Hola, me interesa solicitar una cotización de mobiliario de oficina."

export function CTA() {
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`

  return (
    <section className="py-20 bg-accent">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            <span className="text-balance">¿Listo para Transformar tu Espacio de Trabajo?</span>
          </h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Contáctanos hoy y recibe una cotización personalizada. Nuestro equipo 
            de asesores está listo para ayudarte a encontrar las mejores soluciones 
            para tu oficina.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto">
                <MessageCircle className="mr-2 h-5 w-5" />
                Solicitar Cotización
              </Button>
            </a>
            <a href="tel:+528143910283">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-accent w-full sm:w-auto">
                <Phone className="mr-2 h-5 w-5" />
                Llamar: 81 4391 0283
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
