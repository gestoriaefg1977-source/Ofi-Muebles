import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Award, Users, Building2, ThumbsUp, MessageCircle } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

const stats = [
  { icon: Award, value: "GERSA", label: "Distribuidor Autorizado" },
  { icon: Users, value: "500+", label: "Clientes Satisfechos" },
  { icon: Building2, value: "28+", label: "Años de Experiencia GERSA" },
  { icon: ThumbsUp, value: "100%", label: "Productos de Calidad" },
]

export function About() {
  const whatsappLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent("Hola, me gustaría conocer más sobre OFI-MUEBLES y sus productos.")}`

  return (
    <section id="nosotros" className="py-20 bg-card">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="relative">
            <div className="relative h-[500px] rounded-2xl overflow-hidden">
              <Image
                src="/images/sala-juntas.jpg"
                alt="Nuestra empresa"
                fill
                className="object-cover"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-6 rounded-xl shadow-xl max-w-xs hidden md:block">
              <p className="text-3xl font-bold mb-1">OFI-MUEBLES</p>
              <p className="text-primary-foreground/90 text-sm">
                Productividad en cada espacio
              </p>
              <p className="text-primary-foreground/80 text-xs mt-2">
                Distribuidor Autorizado GERSA
              </p>
            </div>
          </div>

          {/* Content Side */}
          <div>
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">
              Sobre Nosotros
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-6">
              Tu Socio en Soluciones de Mobiliario de Oficina
            </h2>
            
            <div className="space-y-4 text-muted-foreground leading-relaxed mb-8">
              <p>
                En <strong className="text-foreground">OFI-MUEBLES</strong> somos 
                <strong className="text-primary"> distribuidores autorizados de GERSA</strong>, 
                una de las empresas líderes en fabricación de muebles de oficina en México con 
                más de 28 años de experiencia. Nos especializamos en ofrecer soluciones integrales 
                para espacios de trabajo que combinan diseño, ergonomía y funcionalidad.
              </p>
              <p>
                GERSA cuenta con más de 10,000 m² de almacén, showroom y oficinas, además de 
                maquinaria de control numérico de alta precisión para garantizar que cada producto 
                cumpla con los más altos estándares de calidad. Nuestro compromiso es transformar 
                tu espacio de trabajo en un ambiente que impulse la productividad y el bienestar 
                de tu equipo.
              </p>
              <p>
                <strong className="text-foreground">Tiempos de entrega:</strong> Sillería de 1-2 días, 
                mobiliario en stock 1-3 días, mobiliario de fabricación 15-25 días (sujeto a existencia 
                y volúmenes de compra).
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="flex items-center gap-3 p-4 bg-secondary rounded-lg">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <stat.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground w-full sm:w-auto">
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Contáctanos
                </Button>
              </a>
              <Link href="/catalogo">
                <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground w-full sm:w-auto">
                  Ver Catálogo
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
