"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, Clock, Tag, Percent, ArrowRight } from "lucide-react"

const WHATSAPP_NUMBER = "528119530718"

// Ofertas de ejemplo - en producción vendrían de la base de datos
const ofertas = [
  {
    id: 1,
    titulo: "Silla Ejecutiva BOLT ALTA",
    descripcion: "Silla ergonómica de respaldo alto con diseño moderno",
    imagen: "/images/productos/bolt-alta.jpg",
    descuento: 15,
    badge: "Oferta Limitada",
    fechaFin: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 días
    activa: true
  },
  {
    id: 2,
    titulo: "Mesa Abatible FOLD",
    descripcion: "Mesa plegable perfecta para espacios versátiles",
    imagen: "/images/productos/mesa-fold.jpg",
    descuento: 20,
    badge: "Por Tiempo Limitado",
    fechaFin: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 días
    activa: true
  },
  {
    id: 3,
    titulo: "Bench Tapizado 4 Plazas",
    descripcion: "Banca de espera premium con tapizado de alta calidad",
    imagen: "/images/productos/bench-tapizado-4.jpg",
    descuento: 10,
    badge: "Descuento Especial",
    fechaFin: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 días
    activa: true
  }
]

function CountdownTimer({ targetDate }: { targetDate: Date }) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = targetDate.getTime() - Date.now()
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)
    return () => clearInterval(timer)
  }, [targetDate])

  return (
    <div className="flex items-center gap-2 text-sm">
      <Clock className="h-4 w-4 text-primary" />
      <span className="text-muted-foreground">Termina en:</span>
      <div className="flex gap-1">
        <span className="bg-accent text-white px-2 py-1 rounded text-xs font-mono">
          {timeLeft.days}d
        </span>
        <span className="bg-accent text-white px-2 py-1 rounded text-xs font-mono">
          {timeLeft.hours}h
        </span>
        <span className="bg-accent text-white px-2 py-1 rounded text-xs font-mono">
          {timeLeft.minutes}m
        </span>
        <span className="bg-accent text-white px-2 py-1 rounded text-xs font-mono">
          {timeLeft.seconds}s
        </span>
      </div>
    </div>
  )
}

export function SpecialOffers() {
  const ofertasActivas = ofertas.filter(o => o.activa)
  
  if (ofertasActivas.length === 0) return null

  const solicitarInfo = (titulo: string, descuento: number) => {
    const mensaje = `Hola, me interesa la oferta de ${titulo} con ${descuento}% de descuento`
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(mensaje)}`, "_blank")
  }

  return (
    <section id="ofertas" className="py-20 bg-gradient-to-b from-primary/5 to-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-red-500/10 text-red-600 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <Tag className="h-4 w-4" />
            Ofertas Especiales
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Promociones por Tiempo Limitado
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Aprovecha nuestros descuentos especiales en productos seleccionados. 
            Ofertas válidas por tiempo limitado o hasta agotar existencias.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {ofertasActivas.map((oferta) => (
            <div
              key={oferta.id}
              className="group bg-card rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border border-border relative"
            >
              {/* Discount Badge */}
              <div className="absolute top-4 right-4 z-10">
                <div className="bg-red-500 text-white px-3 py-2 rounded-lg font-bold flex items-center gap-1 shadow-lg">
                  <Percent className="h-4 w-4" />
                  <span className="text-lg">-{oferta.descuento}%</span>
                </div>
              </div>

              {/* Image */}
              <div className="relative aspect-square overflow-hidden bg-secondary">
                <Image
                  src={oferta.imagen}
                  alt={oferta.titulo}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground">
                  {oferta.badge}
                </Badge>
                
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-accent/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <Button 
                    onClick={() => solicitarInfo(oferta.titulo, oferta.descuento)}
                    className="bg-primary hover:bg-primary/90"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Solicitar Oferta
                  </Button>
                </div>
              </div>
              
              {/* Content */}
              <div className="p-5">
                <h3 className="font-bold text-lg text-foreground mb-2">
                  {oferta.titulo}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {oferta.descripcion}
                </p>
                
                {/* Countdown */}
                <div className="mb-4">
                  <CountdownTimer targetDate={oferta.fechaFin} />
                </div>

                <Button 
                  onClick={() => solicitarInfo(oferta.titulo, oferta.descuento)}
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Cotizar con Descuento
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link href="/catalogo">
            <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
              Ver Todos los Productos
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
