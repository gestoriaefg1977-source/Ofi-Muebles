export interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  image_url: string | null
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  name: string
  slug: string
  description: string | null
  category_id: string | null
  image_url: string | null
  features: string[] | null
  is_new: boolean
  is_featured: boolean
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
  category?: Category
}

export interface Offer {
  id: string
  product_id: string | null
  title: string
  description: string | null
  discount_percentage: number | null
  badge_text: string
  start_date: string
  end_date: string | null
  is_active: boolean
  created_at: string
  updated_at: string
  product?: Product
}
